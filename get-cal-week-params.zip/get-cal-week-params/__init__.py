import logging
import datetime
import logging
import azure.functions as func
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    try:
        logging.info("Current UTC date : {}".format(datetime.datetime.utcnow()))
        current_year=datetime.datetime.utcnow().isocalendar()[0]
        current_week_of_year=datetime.datetime.utcnow().isocalendar()[1]
        current_weekday=datetime.datetime.utcnow().isocalendar()[2]
        start_calweek="[{}{}]".format(current_year,current_week_of_year-2)
        end_calweek="[{}{}]".format(current_year,current_week_of_year-1)
        logging.info("Current year : {}, Current Week : {}, Current Weekday : {} ".format(current_year,current_week_of_year,current_weekday))
        logging.info("Calweek Start : {}, Calweek End : {} ".format(start_calweek,end_calweek))
        return func.HttpResponse(
            json.dumps({
                "start_calweek":start_calweek,
                "end_calweek":end_calweek
            })
        )

    except Exception as error:
        logging.info("Error Occured while getting Calweek range due to : {}".format(error))
        return func.HttpResponse(
            json.dumps({
                "error":str(error)
            })
        )

